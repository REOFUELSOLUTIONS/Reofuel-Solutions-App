REOFUEL SOLUTIONS WEB APP - VERSION 2

Open index.html in Chrome.

Features:
- Customer automatic IDs RF-0001, RF-0002...
- Customer name, number, address, rate/kg, status, notes
- Container Required Yes/No
- If Yes, at least one container size/quantity is required
- Sizes: 10L, 20L, 25L, 30L, 35L, 40L, 45L, 50L, 55L, 60L
- Separate Container Given checkbox
- Pending Containers menu
- Mark Container Given from pending list
- Local browser storage
- JSON Backup and Restore
- Reofuel logo
- System font similar to modern chat apps

IMPORTANT: A standalone Chrome page cannot automatically email data in the background. The Backup page provides download/share. For automatic Google Drive/Sheets backup, deploy the app with Google Apps Script and connect it to a Google Sheet.
