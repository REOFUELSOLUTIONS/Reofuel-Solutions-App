package com.reofuel.solutions;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new BackupBridge(), "ReofuelAndroid");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    public class BackupBridge {
        @JavascriptInterface public void emailBackup(String json) {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setData(android.net.Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{""});
            i.putExtra(Intent.EXTRA_SUBJECT, "Reofuel Solutions Customer Backup");
            i.putExtra(Intent.EXTRA_TEXT, json);
            startActivity(Intent.createChooser(i, "Send Reofuel Backup"));
        }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
