# Reofuel Solutions Android App — V2

This is a native Android WebView app project for Reofuel Solutions.

## Included
- Reofuel logo as app branding/icon
- Automatic RF-0001 customer IDs
- Customer name, phone, address, rate/kg, status, notes
- Container Required toggle
- Container sizes: 10L, 20L, 25L, 30L, 35L, 40L, 45L, 50L, 55L, 60L
- Per-size container count, allowing e.g. 2 x 25L + 1 x 50L
- Separate Container Given status
- Pending Containers menu and Mark as Given action
- Search/edit customer records
- JSON backup export/restore
- Email backup action through the phone's mail app

## Important
The project is ready to open/build in Android Studio. A compiled APK is not included because this environment does not contain the Android SDK/build tools. For true automatic cloud backup, connect the production app to a secure Google Drive/cloud database; the current Email Backup action opens the user's email app and places the backup in the message body.
